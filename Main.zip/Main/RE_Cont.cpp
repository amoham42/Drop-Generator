#define ESP_DRD_USE_SPIFFS true
#include <FS.h>
#include <SPIFFS.h>
#include "RE_Cont.h"
#define CLK 16
#define DT 4
#define SW 18

int counter = 0;
int currentStateCLK;
int lastStateCLK;
String currentDir ="";
unsigned long lastButtonPress = 0;
int direcSig = 0;
bool btnPressed = false;

void rclass::reSetup() {
  pinMode(CLK,INPUT);
  pinMode(DT,INPUT);
  pinMode(SW, INPUT);
  pinMode(2, OUTPUT);
  lastStateCLK = digitalRead(CLK);
}


void rclass::re_check() {
  currentStateCLK = digitalRead(CLK);
  
  if (currentStateCLK != lastStateCLK  && currentStateCLK == 1){
    if (digitalRead(DT) != currentStateCLK) {
      counter --;
      currentDir ="CCW";
      direcSig = -1;
    } else {
      counter ++;
      currentDir ="CW";
      direcSig = 1;
    } 
  }

  lastStateCLK = currentStateCLK;
  
  int btnState = digitalRead(SW);
  if (btnState == LOW) {
    if (millis() - lastButtonPress > 50) {
      btnPressed = true;
    }
    lastButtonPress = millis();
  }
  delay(1);
}

int rclass::getDirection(){
  if(currentDir == "CW"){
    return 1;
  }
  else{
    return -1;
  }
}

int rclass::getupdownSignal(){
  return direcSig;
}

void rclass::setupdownSignal(){
  direcSig = 0;
}

int rclass::getCount(){
  return counter;
}

bool rclass::isBtnPressed(){
  if(btnPressed){
    btnPressed = false;
    return true;
  }
  else{
    return false;
  }
}
