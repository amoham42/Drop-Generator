#ifndef LED_Cont_H
#define LED_Cont_H

#include "RE_Cont.h"
#include "Wifi_Cont.h"
#include "Drop_Gen.h"

class lclass
{
  public:
    lclass();
    void OLED_setup();
    void OLED_loop(rclass, wclass, dclass);
    bool getChanging();
    bool getGenStart();
};


#endif
