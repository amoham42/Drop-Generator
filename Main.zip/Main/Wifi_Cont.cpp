#define ESP_DRD_USE_SPIFFS true
#include <FS.h>
#include <SPIFFS.h>
#include <WiFi.h>
#include <WiFiServer.h>
#include "Wifi_Cont.h"

const char* ssid = "RLAB";
const char* password = "metropolis";

WiFiServer server(80);

String header;
String camerav = "off";
String dpGen = "off";
String reset = "NoReset";
String pulseWidth = "1000";
String dpDelay = "500";
String dpCount = "100";

int val1[3];
String tempVal[3];

bool change = false;
bool camwifi = false;
bool drpGen = false;
bool res = false;
int pulsav = 1000;
int dpDel = 500;
int dpCnt = 100;
bool tcamwifi = false;
bool tdrpGen = false;
bool tres = false;
int tpulsav = 1000;
int tdpDel = 500;
int tdpCnt = 100;

unsigned long currentTime = millis();
unsigned long previousTime = 0;
const long timeoutTime = 2000;

IPAddress local_IP(138, 16, 161, 200);
IPAddress gateway(138, 16, 161, 1);
IPAddress subnet(255, 255, 255, 255);

void wclass::wfSetup() {
  WiFi.config(local_IP, gateway, subnet);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
  server.begin();
}

bool wclass::getCam(){
  return camwifi;
}

bool wclass::getDrpGen(){
  return drpGen;
}

bool wclass::getRes(){
  return res;
}

int wclass::getPulse(){
  return pulsav;
}

int wclass::getDpDel(){
  return dpDel;
}
int wclass::getDpCnt(){
  return dpCnt;
}

bool wclass::getChange(){
  return change;
}

void wclass::setChange(bool value){
  change = value;
}

void wclass::wfRun() {
  
  WiFiClient client = server.available();
  if (client) {
    currentTime = millis();
    previousTime = currentTime;
    String currentLine = "";
    while (client.connected() && currentTime - previousTime <= timeoutTime) {
      currentTime = millis();
      if (client.available()) {
        char c = client.read();
        header += c;
        if (c == '\n') {

          if (currentLine.length() == 0) {

            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println("Connection: close");
            client.println();
            if (header.indexOf("GET /CAM/on") >= 0 && camerav == "off") {
              camerav = "on";
              camwifi = true;
            }
            else if (header.indexOf("GET /CAM/off") >= 0 && camerav == "on") {
              camerav = "off";
              camwifi = false;
            }
            else if (header.indexOf("GET /DPG/on") >= 0 && dpGen == "off") {
              dpGen = "on";
              drpGen = true;
            }
            else if (header.indexOf("GET /DPG/off") >= 0 && dpGen == "on") {
              dpGen = "off";
              drpGen = false;
            }
            else if (header.indexOf("GET /REST/on") >= 0 && res == false) {
              res = true;
            }
            else if(header.indexOf("GET /pls?NUM=") >= 0) {
              val1[0] = header.indexOf('=');
              tempVal[0] = header.substring(val1[0] + 1, header.length() - 1);
              pulsav = tempVal[0].toInt();
              pulseWidth = tempVal[0];}
            else if(header.indexOf("GET /del?NUM=") >= 0) {
              val1[1] = header.indexOf('=');
              tempVal[1] = header.substring(val1[1] + 1, header.length() - 1);
              dpDel = tempVal[1].toInt();
              dpDelay = tempVal[1];}
            else if(header.indexOf("GET /cnt?NUM=") >= 0) {
              val1[2] = header.indexOf('=');
              tempVal[2] = header.substring(val1[2] + 1, header.length() - 1);
              dpCnt = tempVal[2].toInt();
              dpCount = tempVal[2];}
            if(tcamwifi != camwifi || tdrpGen != drpGen || tres != res || tpulsav != pulsav || tdpDel != dpDel || tdpCnt != dpCnt){
              change = true;
              tcamwifi = camwifi;
              tdrpGen = dpGen;
              tres = res;
              tpulsav = pulsav;
              tdpDel = dpDel;
              tdpCnt = dpCnt;
            }
            client.println("<!DOCTYPE html><html>");
            client.println("<head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            client.println("<link rel=\"icon\" href=\"data:,\">");
            client.println("<style>html { font-family: Helvetica; display: inline-block; margin: 0px auto; text-align: center;}");
            client.println("body { text-align: center; font-family: \"Trebuchet MS\", Arial; margin-left:auto; margin-right:auto;}");
            client.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
            client.println(".button { background-color: #4CAF50; border: none; color: white; padding: 16px 40px;");
            client.println("text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}");
            client.println(".button2 {background-color: #555555;}</style></head>");
            client.println("<body>");
            client.println("<h2>Harris Lab Droplet Generator</h2>");
            client.println("<p>Camera - State</p>");
            client.println("<p>" + camerav + "</p>");
            if (camerav == "off") {
              client.println("<p><a href=\"/Cam/on\"><button class=\"button\">ON</button></a></p>");
              res = false;
            }
            else {
              client.println("<p><a href=\"/Cam/off\"><button class=\"button button2\">OFF</button></a></p>");
              res = false;
            }
            
            client.println("<p>Droplet Generator - State</p>");
            client.println("<p>" + dpGen + "</p>");
            if (dpGen == "off") {
              client.println("<p><a href=\"/DPG/on\"><button class=\"button\">ON</button></a></p>");
              res = false;
            }
            else {
              client.println("<p><a href=\"/DPG/off\"><button class=\"button button2\">OFF</button></a></p>");
              res = false;
            }
            client.println("<p>Genreral Settings RESET</p>");
            if (reset == "NoReset") {
              client.println("<p><a href=\"/REST/on\"><button class=\"button\">RESET</button></a></p>");
            }
            client.println("<p>pulse Width (Microseconds)<p>");
            client.println("<p>" + String(pulsav) + "</p>");
            client.println("<form action=\"/pls\"><label for=\"plsSlider\"></label>");
            client.println("<p><input type=\"number\" min=\"100\" max=\"3000\" id=\"plsSlider\" name=\"NUM\">");
            client.println("<input type=\"submit\"><\form>");
            
            client.println("<p>Droplet Delay (Milliseconds)<p>");
            
            client.println("<p>" + String(dpDel) + "</p>");
            client.println("<form action=\"/del\"><label for=\"delSlider\"></label>");
            client.println("<p><input type=\"number\" min=\"100\" max=\"3000\" id=\"delSlider\" name=\"NUM\">");
            client.println("<input type=\"submit\"><\form>");
            
            client.println("<p>Droplet Number<p>");
            client.println("<p>" + String(dpCnt) + "</p>");
            client.println("<form action=\"/cnt\"><label for=\"cntSlider\"></label>");
            client.println("<p><input type=\"number\" min=\"100\" max=\"3000\" id=\"cntSlider\" name=\"NUM\">");     
            client.println("<input type=\"submit\"><\form>");
            client.println("</body></html>");
            client.println();
            break;
          }
          else { 
            currentLine = "";
          }
        } else if (c != '\r') { 
          currentLine += c;   
        }
      }
    }
    header = "";

    client.stop();
  }
}
