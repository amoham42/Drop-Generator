#define ESP_DRD_USE_SPIFFS true
#include <FS.h>
#include <SPIFFS.h>
#include "Drop_Gen.h"
const int DIR_A = 19;
const int DIR_B = 17;
const int trigger = 23;
const int delayTime = 15;
int pulsewidth = 1000;
int dropletDelay = 500;
int dropNum = 100;
int counterr = dropNum;
bool camera = false;
bool staterr = false;


void dclass::dgSetup(){
  pinMode (2, OUTPUT);
  pinMode(DIR_A, OUTPUT);
  pinMode(DIR_B, OUTPUT);
  pinMode(trigger, OUTPUT);
  digitalWrite(2, HIGH); // BUILTIN_LED LIGHT ON
}

void dclass::dgStart(){
  if(staterr && counterr > 0){
    digitalWrite(DIR_A, HIGH); // Turn on left : high low
    digitalWrite(DIR_B, LOW);
    delayMicroseconds(pulsewidth); //pulse width  for which piezoelectic actuator is activated inmicroseconds
    digitalWrite(DIR_A, LOW); // Turn on right : low high
    digitalWrite(DIR_B, HIGH);
    if(camera){
      delay(delayTime);
  digitalWrite(trigger, HIGH);
  delayMicroseconds(6);
  digitalWrite(trigger, LOW);
    }
  counterr--;
  delay(dropletDelay);
  }
}

void dclass::setPulseWidth(int pulse){
  if(pulse > 100 && pulse < 3000){
    pulsewidth = pulse;
  }
}

int dclass::getPulseWidth(){
  return pulsewidth;
}

void dclass::setDropletDelay(int drpDel){
  if(drpDel > 100 && drpDel < 3000){
    dropletDelay = drpDel;
  }
}

int dclass::getDropletDelay(){
  return dropletDelay;
}
void dclass::setCamera(bool cam){
  camera = cam;
}

bool dclass::getCamera(){
  return camera;
}

void dclass::setDropNum(int number){
  if(number >= 1){
    dropNum = number;
  }
}

int dclass::getDropNum(){
  return counterr;
}

void dclass::setDpGen(bool states){
  staterr = states;
}

bool dclass::getDpGen(){
  return staterr;
}
