#ifndef Drop_Gen_H
#define Drop_Gen_H

class dclass{

  public:

    void dgSetup();
    void dgStart();
    void setPulseWidth(int);
    int getPulseWidth();
    void setDropletDelay(int);
    int getDropletDelay();
    void setCamera(bool);
    bool getCamera();
    void setDropNum(int);
    int getDropNum();
    void setDpGen(bool);
    bool getDpGen();
};

#endif
