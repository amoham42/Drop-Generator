#ifndef RE_Cont_H
#define RE_Cont_H

class rclass{

  public:
    void reSetup();
    void re_check();
    int getDirection();
    int getupdownSignal();
    void setupdownSignal();
    int getCount();
    bool isBtnPressed();
};

#endif
