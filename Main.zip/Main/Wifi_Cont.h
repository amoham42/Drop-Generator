#ifndef Wifi_Cont_H
#define Wifi_Cont_H

class wclass{
  public:
    void wfSetup();
    void wfRun();
    bool getCam();
    bool getDrpGen();
    bool getRes();
    int getPulse();
    int getDpDel();
    int getDpCnt();
    bool getChange();
    void setChange(bool);
};

#endif
